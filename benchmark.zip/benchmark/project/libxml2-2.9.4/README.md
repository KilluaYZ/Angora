# Initial Seed Corpus

Copied the seeds from 'test/dtd\*' and 'test/dtds/\*', by referring to the
fuzzing scripts in the AFLGo repository. Then, removed 'dtd1' because it caused
timeout when executed with '--valid" option.
