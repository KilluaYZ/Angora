#! /bin/bash

if [ $# -ne 2 ] ; then
    echo "Usage: $0 <target program> <cmdline>"
    exit 1
fi

TARGET=$1
INPUT_PATH=/benchmark/seed/$TARGET
OUTPUT_PATH=/tests/$1
TAINT_PROG=/benchmark/bin/Angora/$1-track
FAST_PROG=/benchmark/bin/Angora/$1-fast
ARGS=$2
echo TAINT_PROG=$TAINT_PROG
echo FAST_PROG=$FAST_PROG
/Angora/angora_fuzzer -i $INPUT_PATH -o $OUTPUT_PATH -t $TAINT_PROG -- $FAST_PROG $ARGS